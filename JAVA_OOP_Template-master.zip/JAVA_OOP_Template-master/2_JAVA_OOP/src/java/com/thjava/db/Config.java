package com.thjava.db;

public class Config {

    public static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String utf_8 = "?useUnicode=true&characterEncoding=UTF-8";
    public static final String URL = "jdbc:mysql://localhost:3306/JAVA_OOP_V1" + utf_8;
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    
} // class Config


