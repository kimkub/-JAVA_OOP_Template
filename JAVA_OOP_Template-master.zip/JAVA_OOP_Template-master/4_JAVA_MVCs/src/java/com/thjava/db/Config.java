package com.thjava.db;

public class Config {

    // 1. ประกาศตัวแปร และกำหนดค่าเริ่มต้น
    public static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String UTF_8 = "?useUnicode=true&characterEncoding=UTF-8";
    public static final String URL = "jdbc:mysql://localhost:3306/JAVA_OOP_V1" + UTF_8;
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    
    
} // class Config                                  

